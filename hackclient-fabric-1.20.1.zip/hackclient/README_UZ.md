# Pista Client 2.3 (Fabric 1.20.1)

29 modul, ikki til, ClickGUI. Hali o'zim kompilyatsiya qilib ko'rmaganman.

## Bu safargi o'zgarishlar
- **GUI torroq edi, tuzatildi:** qator balandligi va bo'shliqlar kattalashtirildi, tugmalar va slayderlar kattaroq.
  Hali ham siqiq ko'rinsa, aytng — yana kattalashtiramiz.
- **HUD -> ListOffsetY:** o'ng tomondagi modul ro'yxatini pastga suring, server o'zining interfeysi bilan
  ustma-ust tushmasin (ekranda ko'rgan "ANARXIYA" paneli kabi).
- **TargetESP (Render):** alohida modul, ESP yoqilmagan bo'lsa ham ishlaydi. KillAura yoki TriggerBot
  nishon olgan mobni quti, ism va HP chizig'i bilan ko'rsatadi.
- **Yangi modullar:** Speed, NoFall, Scaffold.

## Bypass haqida yana bir bor ochiq gap
KillAura'ga maxsus "AI anticheat'ni aldash" mantig'i qo'shmayapman va qo'shmayman — bunga hech kim kafolat
bera olmaydi, faqat bitta aniq tizimni maqsadli yengishga aylanadi. Bor narsa shu: Silent rotation, GCD
(sichqoncha qadamiga moslash), Legit/Normal/Rage preset, OnlyCrits. Eng xavfsiz yo'l — Legit preset +
past Range/FOV + real o'yinchidek tanaffuslar bilan aralashtirib ishlatish. Speed, Scaffold, NoFall ham
oddiy variantlar: ko'p zamonaviy serverda harakat tekshiruvi kuchli bo'lsa, tez aniqlanadi.

## Yangilash (GitHub'da)
Eski zip ustiga shu nomdagi yangisini yuklang, commit qiling. Yangi jar: `hackclient-2.3.0.jar`.

## Boshqarish
- GUI: o'ng Shift yoki chatga `.gui`. Til: Utils -> Language, yoki `.lang uz` / `.lang en`.
- Chat: `.help`, `.lang en|uz`, `.toggle <modul>`, `.bind <modul> <tugma|none>`, `.friend add|remove|list <ism>`.
