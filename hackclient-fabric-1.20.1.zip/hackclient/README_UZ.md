# Pista Client 2.2 (Fabric 1.20.1)

ClickGUI, HUD, 26 modul, Ingliz/O'zbek interfeys. Hali o'zim kompilyatsiya qilib ko'rmaganman.
Bu versiyada yangi mixin yoki risksiz API ishlatilmadi (eski 2.1 bilan bir xil asosda), shuning uchun
agar 2.1 build muvaffaqiyatli bo'lgan bo'lsa, bu ham o'tishi kerak.

## Logo
Siz yuborgan rasm mod ikonkasi sifatida qo'yildi (launcher/mod ro'yxatida ko'rinadi).
Uni HUD yoki GUI ichiga haqiqiy rasm sifatida chizish uchun qo'shimcha texture-yuklash kodi kerak,
bu safar uni qo'shmadim, chunki yangi, sinalmagan API qatlamini kiritib, buildni xavf ostiga qo'ymoqchi emasman.
Xohlasangiz keyingi qadamda shuni ham qo'shamiz.

## Til
- Utils -> Language -> English / Uzbek. GUI, bildirishnomalar va chat buyruqlari javoblari shunga qarab o'zgaradi.
- Tezroq: chatga `.lang uz` yoki `.lang en`.
- Modul va sozlama nomlari doim ingliz tilida qoladi (bu turdagi barcha klientlarda shunday, `.bind KillAura r` kabi buyruqlar ishlashi uchun).

## KillAura
- **Preset:** Legit (sekin, tor, faqat crit), Normal, Rage (tez, keng). Bu faqat mavjud sonli sozlamalarni (Range/FOV/TurnSpeed/MinCooldown) bir marta o'rnatadi, maxsus "aldash" mantig'i emas.
- **Rotation:** Silent (kamera erkin), Visible, Off.
- **OnlyCrits / CritJump / TargetHighlight** (ESP ichida, joriy nishonni oq chiziq bilan ajratadi).

## Yangilash (GitHub'da)
Eski zip ustiga shu nomdagi yangisini yuklang, commit qiling. Yangi jar: `hackclient-2.2.0.jar`.

## Boshqarish
- GUI: o'ng Shift yoki chatga `.gui`.
- Chat: `.help`, `.lang en|uz`, `.toggle <modul>`, `.bind <modul> <tugma|none>`, `.friend add|remove|list <ism>`.
