# HackClient 2.1 (Fabric 1.20.1)

ClickGUI (5 yumaloq panel) va 25 modul. Silent rotation, OnlyCrits, TargetHUD, bildirishnomalar.
Hali o'zim kompilyatsiya qilib ko'rmaganman: birinchi build xato bersa, log'ni yuboring.

## Yangilash (GitHub'da)
1. Reponi oching, eski `hackclient-fabric-1.20.1.zip` ustiga SHU NOMDAGI yangi zipni yuklang ("Add file" -> "Upload files").
2. Commit qiling. Actions o'zi qayta quradi. Yangi jar nomi: `hackclient-2.1.0.jar`.

## O'yinga
Eski `hackclient-2.0.0.jar` ni `mods` papkasidan O'CHIRING, yangisini qo'ying. Fabric API qolsin.

## Boshqarish
- GUI: o'ng Shift (yoki Pojav ekran tugmasi), yoki chatga `.gui`.
- Modul ustiga bosing = yoqish/o'chirish. "+" = sozlamalar (ichida Bind).
- KillAura: Range, Rotation (Silent/Visible/Off), OnlyCrits. Qolganlari "Advanced" ichida.
- Chat: `.help`, `.toggle <modul>`, `.bind <modul> <tugma|none>`, `.friend add|remove|list <ism>`.
- Rang: HUD -> Accent.
