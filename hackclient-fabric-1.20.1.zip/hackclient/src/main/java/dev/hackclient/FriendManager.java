package dev.hackclient;

import java.util.Collections;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

public final class FriendManager {
    private static final Set<String> FRIENDS = new TreeSet<>();

    private FriendManager() {
    }

    public static boolean isFriend(String name) {
        return name != null && FRIENDS.contains(name.toLowerCase(Locale.ROOT));
    }

    public static void add(String name) {
        FRIENDS.add(name.toLowerCase(Locale.ROOT));
    }

    public static boolean remove(String name) {
        return FRIENDS.remove(name.toLowerCase(Locale.ROOT));
    }

    public static Set<String> all() {
        return Collections.unmodifiableSet(FRIENDS);
    }
}
