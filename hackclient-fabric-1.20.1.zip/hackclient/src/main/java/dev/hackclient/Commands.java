package dev.hackclient;

import dev.hackclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Locale;

/** Chat commands, handy on phones where a keyboard is not available. Messages starting with "." that are not commands pass through. */
public final class Commands {
    private Commands() {
    }

    /** Returns true when the message was a command and must not be sent to the server. */
    public static boolean handle(String raw) {
        if (!raw.startsWith(".")) {
            return false;
        }
        String[] a = raw.substring(1).trim().split("\\s+");
        if (a.length == 0 || a[0].isEmpty()) {
            return false;
        }
        String cmd = a[0].toLowerCase(Locale.ROOT);
        if (cmd.equals("gui")) {
            HackClient.requestOpenGui();
            return true;
        }
        if (cmd.equals("help")) {
            info("Commands: .gui | .toggle <module> | .bind <module> <key|none> | .friend add|remove|list <name>");
            return true;
        }
        if (cmd.equals("toggle") || cmd.equals("t")) {
            toggle(a);
            return true;
        }
        if (cmd.equals("bind")) {
            bind(a);
            return true;
        }
        if (cmd.equals("friend") || cmd.equals("f")) {
            friend(a);
            return true;
        }
        return false;
    }

    private static void toggle(String[] a) {
        if (a.length < 2) {
            info("Usage: .toggle <module>");
            return;
        }
        Module m = HackClient.modules().byName(a[1]);
        if (m == null) {
            info("Unknown module: " + a[1]);
            return;
        }
        m.toggle();
        info(m.getName() + (m.isEnabled() ? " enabled" : " disabled"));
    }

    private static void bind(String[] a) {
        if (a.length < 3) {
            info("Usage: .bind <module> <key|none>   e.g. .bind KillAura r");
            return;
        }
        Module m = HackClient.modules().byName(a[1]);
        if (m == null) {
            info("Unknown module: " + a[1]);
            return;
        }
        String key = a[2].toLowerCase(Locale.ROOT);
        if (key.equals("none")) {
            m.setKey(-1);
            info(m.getName() + " unbound");
        } else {
            try {
                m.setKey(InputUtil.fromTranslationKey("key.keyboard." + key).getCode());
                info(m.getName() + " bound to " + key.toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                info("Unknown key: " + a[2]);
                return;
            }
        }
        Config.save(HackClient.modules());
    }

    private static void friend(String[] a) {
        if (a.length >= 2 && a[1].equalsIgnoreCase("list")) {
            info("Friends: " + (FriendManager.all().isEmpty() ? "(none)" : String.join(", ", FriendManager.all())));
            return;
        }
        if (a.length < 3) {
            info("Usage: .friend add|remove <name>  or  .friend list");
            return;
        }
        if (a[1].equalsIgnoreCase("add")) {
            FriendManager.add(a[2]);
            info("Added friend " + a[2]);
        } else if (a[1].equalsIgnoreCase("remove")) {
            info(FriendManager.remove(a[2]) ? "Removed friend " + a[2] : a[2] + " is not a friend");
        } else {
            info("Usage: .friend add|remove <name>  or  .friend list");
            return;
        }
        Config.save(HackClient.modules());
    }

    private static void info(String message) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud != null) {
            mc.inGameHud.getChatHud().addMessage(Text.literal("[HackClient] ").formatted(Formatting.AQUA)
                    .append(Text.literal(message).formatted(Formatting.WHITE)));
        }
    }
}
