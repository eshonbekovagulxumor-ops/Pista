package dev.hackclient;

import dev.hackclient.module.Module;
import dev.hackclient.util.Lang;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Locale;

/** Chat commands, handy on phones where a keyboard is not available. Messages starting with "." that are not commands pass through. */
public final class Commands {
    private Commands() {
    }

    /** Returns true when the message was a command and must not be sent to the server. */
    public static boolean handle(String raw) {
        if (!raw.startsWith(".")) {
            return false;
        }
        String[] a = raw.substring(1).trim().split("\\s+");
        if (a.length == 0 || a[0].isEmpty()) {
            return false;
        }
        String cmd = a[0].toLowerCase(Locale.ROOT);
        if (cmd.equals("gui")) {
            HackClient.requestOpenGui();
            return true;
        }
        if (cmd.equals("help")) {
            info(Lang.t(
                    "Commands: .gui | .lang en|uz | .toggle <module> | .bind <module> <key|none> | .friend add|remove|list <name>",
                    "Buyruqlar: .gui | .lang en|uz | .toggle <modul> | .bind <modul> <tugma|none> | .friend add|remove|list <ism>"));
            return true;
        }
        if (cmd.equals("lang")) {
            lang(a);
            return true;
        }
        if (cmd.equals("toggle") || cmd.equals("t")) {
            toggle(a);
            return true;
        }
        if (cmd.equals("bind")) {
            bind(a);
            return true;
        }
        if (cmd.equals("friend") || cmd.equals("f")) {
            friend(a);
            return true;
        }
        return false;
    }

    private static void lang(String[] a) {
        if (a.length < 2 || !(a[1].equalsIgnoreCase("en") || a[1].equalsIgnoreCase("uz"))) {
            info(Lang.t("Usage: .lang en|uz", "Foydalanish: .lang en|uz"));
            return;
        }
        Module language = HackClient.modules().byName("Language");
        if (language != null) {
            var setting = language.settings().get(0);
            if (setting instanceof dev.hackclient.module.setting.ModeSetting ms) {
                ms.load(new com.google.gson.JsonPrimitive(a[1].equalsIgnoreCase("uz") ? "Uzbek" : "English"));
            }
        }
        info(Lang.t("Language set to English", "Til o'zbekchaga o'rnatildi"));
        Config.save(HackClient.modules());
    }

    private static void toggle(String[] a) {
        if (a.length < 2) {
            info(Lang.t("Usage: .toggle <module>", "Foydalanish: .toggle <modul>"));
            return;
        }
        Module m = HackClient.modules().byName(a[1]);
        if (m == null) {
            info(Lang.t("Unknown module: ", "Noma'lum modul: ") + a[1]);
            return;
        }
        m.toggle();
        info(m.getName() + " " + (m.isEnabled() ? Lang.t("enabled", "yoqildi") : Lang.t("disabled", "o'chirildi")));
    }

    private static void bind(String[] a) {
        if (a.length < 3) {
            info(Lang.t("Usage: .bind <module> <key|none>   e.g. .bind KillAura r",
                    "Foydalanish: .bind <modul> <tugma|none>   masalan: .bind KillAura r"));
            return;
        }
        Module m = HackClient.modules().byName(a[1]);
        if (m == null) {
            info(Lang.t("Unknown module: ", "Noma'lum modul: ") + a[1]);
            return;
        }
        String key = a[2].toLowerCase(Locale.ROOT);
        if (key.equals("none")) {
            m.setKey(-1);
            info(m.getName() + " " + Lang.t("unbound", "bog'lanishi olib tashlandi"));
        } else {
            try {
                m.setKey(InputUtil.fromTranslationKey("key.keyboard." + key).getCode());
                info(m.getName() + " " + Lang.t("bound to ", "bog'landi: ") + key.toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException e) {
                info(Lang.t("Unknown key: ", "Noma'lum tugma: ") + a[2]);
                return;
            }
        }
        Config.save(HackClient.modules());
    }

    private static void friend(String[] a) {
        if (a.length >= 2 && a[1].equalsIgnoreCase("list")) {
            info(Lang.t("Friends: ", "Do'stlar: ")
                    + (FriendManager.all().isEmpty() ? Lang.t("(none)", "(yo'q)") : String.join(", ", FriendManager.all())));
            return;
        }
        if (a.length < 3) {
            info(Lang.t("Usage: .friend add|remove <name>  or  .friend list",
                    "Foydalanish: .friend add|remove <ism>  yoki  .friend list"));
            return;
        }
        if (a[1].equalsIgnoreCase("add")) {
            FriendManager.add(a[2]);
            info(Lang.t("Added friend ", "Do'st qo'shildi: ") + a[2]);
        } else if (a[1].equalsIgnoreCase("remove")) {
            boolean removed = FriendManager.remove(a[2]);
            info(removed ? Lang.t("Removed friend ", "Do'st o'chirildi: ") + a[2]
                    : a[2] + Lang.t(" is not a friend", " do'st emas"));
        } else {
            info(Lang.t("Usage: .friend add|remove <name>  or  .friend list",
                    "Foydalanish: .friend add|remove <ism>  yoki  .friend list"));
            return;
        }
        Config.save(HackClient.modules());
    }

    private static void info(String message) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud != null) {
            mc.inGameHud.getChatHud().addMessage(Text.literal("[Pista] ").formatted(Formatting.LIGHT_PURPLE)
                    .append(Text.literal(message).formatted(Formatting.WHITE)));
        }
    }
}
