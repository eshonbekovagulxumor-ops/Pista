package dev.hackclient.util;

/** Rotation that is sent to the server instead of the camera rotation. Set before the movement packet of a tick is built. */
public final class SilentRotation {
    private static boolean active;
    private static float yaw;
    private static float pitch;

    private SilentRotation() {
    }

    public static void set(float newYaw, float newPitch) {
        yaw = newYaw;
        pitch = newPitch;
        active = true;
    }

    public static void clear() {
        active = false;
    }

    public static boolean isActive() {
        return active;
    }

    public static float yaw() {
        return yaw;
    }

    public static float pitch() {
        return pitch;
    }
}
