package dev.hackclient.util;

import dev.hackclient.module.impl.Language;

/** Tiny translation helper for the client's own chrome: GUI labels, HUD footer, notifications, chat replies. */
public final class Lang {
    private Lang() {
    }

    public static boolean isUzbek() {
        return Language.isUzbek();
    }

    public static String t(String english, String uzbek) {
        return isUzbek() ? uzbek : english;
    }
}
