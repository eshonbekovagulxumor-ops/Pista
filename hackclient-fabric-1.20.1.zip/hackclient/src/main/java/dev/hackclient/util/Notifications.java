package dev.hackclient.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

/** Small toasts shown when a module is switched on or off. */
public final class Notifications {
    private record Entry(String module, boolean on, long time) {
    }

    private static final long LIFETIME_MS = 2500;
    private static final long FADE_MS = 300;
    private static final Deque<Entry> ENTRIES = new ArrayDeque<>();

    private Notifications() {
    }

    public static void push(String module, boolean on) {
        if (MinecraftClient.getInstance().player == null) {
            return;
        }
        ENTRIES.addLast(new Entry(module, on, System.currentTimeMillis()));
        while (ENTRIES.size() > 5) {
            ENTRIES.removeFirst();
        }
    }

    public static void render(DrawContext ctx, TextRenderer tr, int screenW, int screenH) {
        long now = System.currentTimeMillis();
        while (!ENTRIES.isEmpty() && now - ENTRIES.peekFirst().time() > LIFETIME_MS) {
            ENTRIES.removeFirst();
        }
        int y = screenH - 48;
        Iterator<Entry> it = ENTRIES.descendingIterator();
        while (it.hasNext()) {
            Entry e = it.next();
            long age = now - e.time();
            float f = age > LIFETIME_MS - FADE_MS ? Math.max(0.0f, (LIFETIME_MS - age) / (float) FADE_MS) : 1.0f;
            String text = e.module() + " " + (e.on() ? Lang.t("enabled", "yoqildi") : Lang.t("disabled", "o'chirildi"));
            int w = tr.getWidth(text) + 20;
            int x2 = screenW - 6;
            int x1 = x2 - w;
            RenderUtil.roundRect(ctx, x1, y, x2, y + 16, 4, Theme.withAlpha(Theme.HUD_BG, f));
            int dot = e.on() ? 0xFF55E08A : 0xFFFF6B6B;
            RenderUtil.roundRect(ctx, x1 + 5, y + 5, x1 + 11, y + 11, 3, Theme.withAlpha(dot, f));
            ctx.drawTextWithShadow(tr, text, x1 + 15, y + 4, Theme.withAlpha(Theme.TEXT, f));
            y -= 19;
        }
    }
}
