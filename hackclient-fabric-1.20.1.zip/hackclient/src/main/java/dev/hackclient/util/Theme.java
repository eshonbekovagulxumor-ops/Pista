package dev.hackclient.util;

import dev.hackclient.module.impl.Hud;

public final class Theme {
    public static final int TEXT = 0xFFE3E7F0;
    public static final int TEXT_DIM = 0xFF8D96A8;
    public static final int PANEL_BG = 0xE0141821;
    public static final int HUD_BG = 0xB0121620;

    private Theme() {
    }

    public static int accent() {
        return Hud.accent();
    }

    public static int withAlpha(int color, float factor) {
        int a = Math.min(255, Math.max(0, Math.round(((color >>> 24) & 0xFF) * factor)));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    public static int mix(int a, int b, float t) {
        t = Math.max(0.0f, Math.min(1.0f, t));
        int r = Math.round(((a >> 16) & 0xFF) * (1 - t) + ((b >> 16) & 0xFF) * t);
        int g = Math.round(((a >> 8) & 0xFF) * (1 - t) + ((b >> 8) & 0xFF) * t);
        int bl = Math.round((a & 0xFF) * (1 - t) + (b & 0xFF) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }
}
