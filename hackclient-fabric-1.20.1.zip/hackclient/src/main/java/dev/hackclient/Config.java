package dev.hackclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.hackclient.module.Module;
import dev.hackclient.module.ModuleManager;
import dev.hackclient.module.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;

/** Persists keybinds, settings, enabled state and the friend list to config/hackclient.json. */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Set<String> PENDING_ENABLE = new HashSet<>();

    private Config() {
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("hackclient.json");
    }

    /** Restores keys and settings. Enabled state is only queued: the game options do not exist yet at mod init. */
    public static void load(ModuleManager manager) {
        Path f = file();
        if (!Files.isRegularFile(f)) {
            return;
        }
        try (Reader reader = Files.newBufferedReader(f)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
            JsonObject modules = root.has("modules") ? root.getAsJsonObject("modules") : new JsonObject();
            for (Module m : manager.all()) {
                JsonElement el = modules.get(m.getName());
                if (el == null || !el.isJsonObject()) {
                    continue;
                }
                JsonObject o = el.getAsJsonObject();
                if (o.has("key")) {
                    m.setKey(o.get("key").getAsInt());
                }
                if (o.has("settings") && o.get("settings").isJsonObject()) {
                    JsonObject so = o.getAsJsonObject("settings");
                    for (Setting s : m.settings()) {
                        JsonElement se = so.get(s.name);
                        if (se != null) {
                            try {
                                s.load(se);
                            } catch (RuntimeException ignored) {
                                // keep the default for a malformed value
                            }
                        }
                    }
                }
                if (o.has("enabled") && o.get("enabled").getAsBoolean()) {
                    PENDING_ENABLE.add(m.getName());
                }
            }
            if (root.has("friends") && root.get("friends").isJsonArray()) {
                for (JsonElement fe : root.getAsJsonArray("friends")) {
                    FriendManager.add(fe.getAsString());
                }
            }
        } catch (IOException | RuntimeException e) {
            HackClient.LOGGER.warn("Could not read {}: {}", f, e.toString());
        }
    }

    /** Call once the client is fully started. */
    public static void applyEnabled(ModuleManager manager) {
        for (String name : PENDING_ENABLE) {
            Module m = manager.byName(name);
            if (m != null) {
                m.setEnabled(true);
            }
        }
        PENDING_ENABLE.clear();
    }

    public static void save(ModuleManager manager) {
        JsonObject root = new JsonObject();
        JsonObject modules = new JsonObject();
        for (Module m : manager.all()) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            o.addProperty("key", m.getKey());
            JsonObject so = new JsonObject();
            for (Setting s : m.settings()) {
                so.add(s.name, s.save());
            }
            o.add("settings", so);
            modules.add(m.getName(), o);
        }
        root.add("modules", modules);
        JsonArray friends = new JsonArray();
        for (String name : FriendManager.all()) {
            friends.add(name);
        }
        root.add("friends", friends);

        Path f = file();
        try {
            Files.createDirectories(f.getParent());
            try (Writer writer = Files.newBufferedWriter(f)) {
                GSON.toJson(root, writer);
            }
        } catch (IOException e) {
            HackClient.LOGGER.warn("Could not write {}: {}", f, e.toString());
        }
    }
}
