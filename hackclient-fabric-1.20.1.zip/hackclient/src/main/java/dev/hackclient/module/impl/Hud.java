package dev.hackclient.module.impl;

import dev.hackclient.HackClient;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.util.Notifications;
import dev.hackclient.util.RenderUtil;
import dev.hackclient.util.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

public final class Hud extends Module {
    private static final String[] COLOR_NAMES = {"Blue", "Purple", "Pink", "Green", "Orange", "Red"};
    private static final int[] COLORS = {0xFF6C9BFF, 0xFFA66CFF, 0xFFFF6CB4, 0xFF4CE0A0, 0xFFFFA24C, 0xFFFF5C5C};
    private static Hud instance;

    private final ModeSetting color = mode("Accent", "Purple", COLOR_NAMES);
    private final BoolSetting watermark = bool("Watermark", true);
    private final BoolSetting info = bool("Coords+Speed", true);
    private final BoolSetting moduleList = bool("ModuleList", true);
    private final BoolSetting targetHud = bool("TargetHUD", true);
    private final BoolSetting notifications = bool("Notifications", true);

    private double speed;

    public Hud() {
        super("HUD", Category.RENDER, "Watermark, info, module list, target box");
        instance = this;
    }

    /** Accent colour used by the HUD and the ClickGUI. Works even while the HUD module is off. */
    public static int accent() {
        Hud h = instance;
        return h == null ? COLORS[1] : COLORS[h.color.index()];
    }

    @Override
    public boolean showInList() {
        return false;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) {
            return;
        }
        double dx = p.getX() - p.prevX;
        double dz = p.getZ() - p.prevZ;
        speed += (Math.sqrt(dx * dx + dz * dz) * 20.0 - speed) * 0.2;
    }

    @Override
    public void onRender2D(DrawContext ctx, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.options.hudHidden || mc.options.debugEnabled) {
            return;
        }
        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int accent = accent();

        if (watermark.get()) {
            PlayerListEntry entry = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
            String rest = " | " + player.getEntityName() + " | " + mc.getCurrentFps() + " fps"
                    + (entry != null ? " | " + entry.getLatency() + " ms" : "");
            int w = tr.getWidth("HackClient") + tr.getWidth(rest) + 14;
            RenderUtil.roundRect(ctx, 4, 4, 4 + w, 19, 4, Theme.HUD_BG);
            RenderUtil.roundRect(ctx, 4, 4, 7, 19, 2, accent);
            ctx.drawTextWithShadow(tr, "HackClient", 11, 8, accent);
            ctx.drawTextWithShadow(tr, rest, 11 + tr.getWidth("HackClient"), 8, Theme.TEXT);
        }

        if (info.get()) {
            String s = (int) Math.floor(player.getX()) + " " + (int) Math.floor(player.getY()) + " "
                    + (int) Math.floor(player.getZ()) + "  |  " + String.format(java.util.Locale.ROOT, "%.1f", speed) + " b/s";
            int w = tr.getWidth(s) + 12;
            int y2 = sh - 4;
            RenderUtil.roundRect(ctx, 4, y2 - 15, 4 + w, y2, 4, Theme.HUD_BG);
            ctx.drawTextWithShadow(tr, s, 10, y2 - 11, Theme.TEXT);
        }

        if (moduleList.get()) {
            int right = sw - 4;
            int y = 4;
            int index = 0;
            for (Module m : HackClient.modules().listedByWidth(tr)) {
                int w = tr.getWidth(m.getName());
                RenderUtil.roundRect(ctx, right - w - 10, y, right, y + 13, 3, Theme.HUD_BG);
                RenderUtil.roundRect(ctx, right - 3, y + 2, right - 1, y + 11, 1, accent);
                ctx.drawTextWithShadow(tr, m.getName(), right - w - 6, y + 3, Theme.mix(accent, 0xFFFFFFFF, index * 0.07f));
                y += 15;
                index++;
            }
        }

        if (targetHud.get()) {
            LivingEntity target = KillAura.target();
            if (target != null && target.isAlive()) {
                int x = sw / 2 + 24;
                int y = sh / 2 + 24;
                float frac = MathHelper.clamp(target.getHealth() / Math.max(1.0f, target.getMaxHealth()), 0.0f, 1.0f);
                RenderUtil.roundRect(ctx, x, y, x + 112, y + 34, 5, Theme.HUD_BG);
                String name = target.getName().getString();
                if (name.length() > 16) {
                    name = name.substring(0, 16);
                }
                ctx.drawTextWithShadow(tr, name, x + 8, y + 6, Theme.TEXT);
                String hp = String.format(java.util.Locale.ROOT, "%.1f", target.getHealth());
                ctx.drawTextWithShadow(tr, hp, x + 104 - tr.getWidth(hp), y + 6, Theme.TEXT_DIM);
                RenderUtil.roundRect(ctx, x + 8, y + 21, x + 104, y + 27, 3, 0x66000000);
                int barEnd = x + 8 + Math.max(4, Math.round(96 * frac));
                RenderUtil.roundRect(ctx, x + 8, y + 21, barEnd, y + 27, 3, Theme.mix(0xFFFF5C5C, accent, frac));
            }
        }

        if (notifications.get()) {
            Notifications.render(ctx, tr, sw, sh);
        }
    }
}
