package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Client-side night vision, kept above 200 ticks remaining so the vanilla expiry flicker never shows. */
public final class Fullbright extends Module {
    private static final int GRANT_DURATION_TICKS = 1000;
    private static final int REFRESH_BELOW_TICKS = 400;

    private boolean grantedByUs;

    public Fullbright() {
        super("Fullbright", Category.RENDER, "See in the dark");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null) {
            return;
        }
        StatusEffectInstance current = player.getStatusEffect(StatusEffects.NIGHT_VISION);
        if (current == null || current.getDuration() < REFRESH_BELOW_TICKS) {
            player.addStatusEffect(new StatusEffectInstance(
                    StatusEffects.NIGHT_VISION, GRANT_DURATION_TICKS, 0, false, false, false));
            grantedByUs = true;
        }
    }

    @Override
    protected void onDisable() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (grantedByUs && player != null) {
            player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
        grantedByUs = false;
    }
}
