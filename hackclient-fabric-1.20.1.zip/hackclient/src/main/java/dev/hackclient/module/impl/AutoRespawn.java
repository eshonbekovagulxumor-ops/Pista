package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;

public final class AutoRespawn extends Module {
    public AutoRespawn() {
        super("AutoRespawn", Category.PLAYER, "Respawns instantly");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player != null && mc.currentScreen instanceof DeathScreen) {
            mc.player.requestRespawn();
        }
    }
}
