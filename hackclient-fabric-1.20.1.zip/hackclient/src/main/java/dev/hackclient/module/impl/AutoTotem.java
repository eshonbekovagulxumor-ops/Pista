package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

import java.util.concurrent.ThreadLocalRandom;

public final class AutoTotem extends Module {
    private final NumberSetting health = number("Health", 10, 1, 20, 1);
    private final NumberSetting delay = number("DelayTicks", 3, 0, 20, 1);
    private final BoolSetting always = bool("Always", false);
    private int cooldown;

    public AutoTotem() {
        super("AutoTotem", Category.COMBAT, "Moves a totem to the offhand");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.interactionManager == null) {
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        if (mc.currentScreen != null && !(mc.currentScreen instanceof InventoryScreen)) {
            return;
        }
        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            return;
        }
        boolean low = player.getHealth() + player.getAbsorptionAmount() <= health.get();
        if (!low && !always.get()) {
            return;
        }
        int slot = findTotemSlot(player);
        if (slot < 0) {
            return;
        }
        // Button 40 on SWAP exchanges the clicked slot with the offhand.
        mc.interactionManager.clickSlot(player.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, player);
        cooldown = delay.getInt() + ThreadLocalRandom.current().nextInt(2);
    }

    /** Returns a PlayerScreenHandler slot id: hotbar 36..44, main inventory 9..35. */
    private static int findTotemSlot(ClientPlayerEntity player) {
        var main = player.getInventory().main;
        for (int i = 0; i < 36; i++) {
            if (main.get(i).isOf(Items.TOTEM_OF_UNDYING)) {
                return i < 9 ? 36 + i : i;
            }
        }
        return -1;
    }
}
