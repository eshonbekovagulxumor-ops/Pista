package dev.hackclient.module.setting;

import com.google.gson.JsonElement;

import java.util.function.BooleanSupplier;

public abstract class Setting {
    public final String name;
    private BooleanSupplier visibility = () -> true;

    protected Setting(String name) {
        this.name = name;
    }

    /** Hides the setting in the GUI while the supplier returns false. Hidden settings keep their value. */
    public final void setVisibility(BooleanSupplier visibility) {
        this.visibility = visibility;
    }

    public final boolean isVisible() {
        return visibility.getAsBoolean();
    }

    public abstract JsonElement save();

    public abstract void load(JsonElement element);
}
