package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

/**
 * Scales horizontal movement speed by a flat multiplier. This is a plain, old-style speed modifier,
 * not a NCP/Grim-style bypass: most servers with real movement checks will rubber-band or flag it.
 */
public final class Speed extends Module {
    private final NumberSetting multiplier = number("Multiplier", 1.3, 1.05, 2.5, 0.05);

    public Speed() {
        super("Speed", Category.MOVEMENT, "Multiplies horizontal movement speed");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || !player.isOnGround() || player.isUsingItem()) {
            return;
        }
        Vec3d v = player.getVelocity();
        double horizSq = v.x * v.x + v.z * v.z;
        if (horizSq < 0.0004) {
            return;
        }
        player.setVelocity(v.x * multiplier.get(), v.y, v.z * multiplier.get());
    }
}
