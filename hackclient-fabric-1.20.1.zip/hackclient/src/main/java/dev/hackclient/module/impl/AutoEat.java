package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Eats from the hotbar when the food bar is low, then puts your previous slot back. */
public final class AutoEat extends Module {
    private final NumberSetting hunger = number("Hunger", 14, 4, 19, 1);
    private final BoolSetting skipHarmful = bool("SkipHarmful", true);
    private int previousSlot = -1;

    public AutoEat() {
        super("AutoEat", Category.PLAYER, "Eats when hungry");
    }

    @Override
    protected void onDisable() {
        stopEating(MinecraftClient.getInstance());
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.interactionManager == null) {
            previousSlot = -1;
            return;
        }
        if (mc.currentScreen != null) {
            return;
        }
        int food = player.getHungerManager().getFoodLevel();
        if (previousSlot >= 0) {
            if (food >= 20 || !player.getMainHandStack().isFood()) {
                stopEating(mc);
            }
            return;
        }
        if (food > hunger.getInt()) {
            return;
        }
        int slot = findFood(player);
        if (slot < 0) {
            return;
        }
        previousSlot = player.getInventory().selectedSlot;
        player.getInventory().selectedSlot = slot;
        mc.options.useKey.setPressed(true);
    }

    private void stopEating(MinecraftClient mc) {
        if (previousSlot < 0) {
            return;
        }
        mc.options.useKey.setPressed(false);
        if (mc.player != null) {
            mc.player.getInventory().selectedSlot = previousSlot;
        }
        previousSlot = -1;
    }

    private int findFood(ClientPlayerEntity player) {
        int best = -1;
        int bestHunger = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().main.get(i);
            if (!stack.isFood() || stack.isOf(Items.CHORUS_FRUIT)) {
                continue;
            }
            FoodComponent food = stack.getItem().getFoodComponent();
            if (food == null || (skipHarmful.get() && isHarmful(food))) {
                continue;
            }
            if (food.getHunger() > bestHunger) {
                bestHunger = food.getHunger();
                best = i;
            }
        }
        return best;
    }

    private static boolean isHarmful(FoodComponent food) {
        for (var effect : food.getStatusEffects()) {
            if (effect.getFirst().getEffectType().getCategory() == StatusEffectCategory.HARMFUL) {
                return true;
            }
        }
        return false;
    }
}
