package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

import java.util.concurrent.ThreadLocalRandom;

/** Attacks only when the crosshair is already on a valid target; never moves the camera. */
public final class TriggerBot extends Module {
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting hostiles = bool("Hostiles", true);
    private final BoolSetting passives = bool("Passives", false);
    private final BoolSetting onlyCrits = bool("OnlyCrits", false);
    private final BoolSetting onlyWeapon = bool("OnlyWeapon", true);
    private final BoolSetting noUseItem = bool("NoUseItem", true);
    private final NumberSetting minCooldown = number("MinCooldown", 0.92, 0.5, 1.0, 0.01);

    private float requiredCooldown = 1.0f;

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT, "Attacks what your crosshair is on");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.interactionManager == null
                || mc.currentScreen != null || !player.isAlive()) {
            return;
        }
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) {
            return;
        }
        Entity e = hit.getEntity();
        if (!Targets.isAttackable(e, players.get(), hostiles.get(), passives.get(), false)) {
            return;
        }
        if ((onlyWeapon.get() && !Targets.isHoldingWeapon(player)) || (noUseItem.get() && player.isUsingItem())) {
            return;
        }
        if (player.getAttackCooldownProgress(0.5f) < requiredCooldown) {
            return;
        }
        if (onlyCrits.get() && !Targets.canCrit(player)) {
            return;
        }
        mc.interactionManager.attackEntity(player, e);
        player.swingHand(Hand.MAIN_HAND);
        float min = minCooldown.getFloat();
        requiredCooldown = min + ThreadLocalRandom.current().nextFloat() * (1.0f - min);
    }
}
