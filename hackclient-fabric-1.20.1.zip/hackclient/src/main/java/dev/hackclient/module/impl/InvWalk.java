package dev.hackclient.module.impl;

import dev.hackclient.gui.ClickGuiScreen;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

/** Keeps movement keys working while an inventory or the ClickGUI is open. */
public final class InvWalk extends Module {
    public InvWalk() {
        super("InvWalk", Category.MOVEMENT, "Move while menus are open");
    }

    @Override
    public void onPreTick(MinecraftClient mc) {
        Screen screen = mc.currentScreen;
        if (screen == null || mc.player == null) {
            return;
        }
        boolean allowed = (screen instanceof HandledScreen<?> || screen instanceof ClickGuiScreen)
                && !(screen instanceof CreativeInventoryScreen)
                && !(screen instanceof AnvilScreen);
        if (!allowed) {
            return;
        }
        long window = mc.getWindow().getHandle();
        sync(mc.options.forwardKey, window);
        sync(mc.options.backKey, window);
        sync(mc.options.leftKey, window);
        sync(mc.options.rightKey, window);
        sync(mc.options.jumpKey, window);
        sync(mc.options.sprintKey, window);
    }

    private static void sync(KeyBinding binding, long window) {
        InputUtil.Key key = InputUtil.fromTranslationKey(binding.getBoundKeyTranslationKey());
        if (key.getCategory() == InputUtil.Type.KEYSYM) {
            binding.setPressed(InputUtil.isKeyPressed(window, key.getCode()));
        }
    }
}
