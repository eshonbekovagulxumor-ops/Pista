package dev.hackclient.module.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

public final class NumberSetting extends Setting {
    public final double min;
    public final double max;
    public final double step;
    private double value;

    public NumberSetting(String name, double defaultValue, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        set(defaultValue);
    }

    public double get() {
        return value;
    }

    public float getFloat() {
        return (float) value;
    }

    public int getInt() {
        return (int) Math.round(value);
    }

    public void set(double raw) {
        double v = Math.max(min, Math.min(max, raw));
        if (step > 0) {
            v = Math.round((v - min) / step) * step + min;
        }
        value = Math.max(min, Math.min(max, v));
    }

    public void setFromFraction(double fraction) {
        set(min + (max - min) * Math.max(0.0, Math.min(1.0, fraction)));
    }

    public double fraction() {
        return max > min ? (value - min) / (max - min) : 0.0;
    }

    public String display() {
        if (step >= 1.0) {
            return Integer.toString((int) Math.round(value));
        }
        if (step >= 0.1) {
            return String.format(Locale.ROOT, "%.1f", value);
        }
        return String.format(Locale.ROOT, "%.2f", value);
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(value);
    }

    @Override
    public void load(JsonElement element) {
        if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            set(element.getAsDouble());
        }
    }
}
