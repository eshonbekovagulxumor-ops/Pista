package dev.hackclient.module;

import dev.hackclient.HackClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    private final List<Module> listed = new ArrayList<>();
    private boolean listDirty = true;

    public void register(Module module) {
        modules.add(module);
    }

    public List<Module> all() {
        return modules;
    }

    public List<Module> inCategory(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) {
                result.add(m);
            }
        }
        return result;
    }

    public Module byName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) {
                return m;
            }
        }
        return null;
    }

    public <T extends Module> T get(Class<T> type) {
        for (Module m : modules) {
            if (type.isInstance(m)) {
                return type.cast(m);
            }
        }
        return null;
    }

    public void markDirty() {
        listDirty = true;
    }

    /** Enabled modules for the HUD list, widest first. Rebuilt only when a module was toggled. */
    public List<Module> listedByWidth(TextRenderer textRenderer) {
        if (listDirty) {
            listed.clear();
            for (Module m : modules) {
                if (m.isEnabled() && m.showInList()) {
                    listed.add(m);
                }
            }
            listed.sort(Comparator.comparingInt((Module m) -> -textRenderer.getWidth(m.getName())));
            listDirty = false;
        }
        return listed;
    }

    public void preTick(MinecraftClient mc) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                try {
                    m.onPreTick(mc);
                } catch (RuntimeException e) {
                    crashed(m, e);
                }
            }
        }
    }

    public void tick(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();
        boolean canToggle = mc.currentScreen == null && mc.player != null;
        for (Module m : modules) {
            int key = m.getKey();
            if (key < 0) {
                m.keyWasDown = false;
                continue;
            }
            boolean down = InputUtil.isKeyPressed(window, key);
            if (down && !m.keyWasDown && canToggle) {
                m.toggle();
            }
            m.keyWasDown = down;
        }
        for (Module m : modules) {
            if (m.isEnabled()) {
                try {
                    m.onTick(mc);
                } catch (RuntimeException e) {
                    crashed(m, e);
                }
            }
        }
    }

    public void render2D(DrawContext context, float tickDelta) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                try {
                    m.onRender2D(context, tickDelta);
                } catch (RuntimeException e) {
                    crashed(m, e);
                }
            }
        }
    }

    public void gameMessage(String message) {
        for (Module m : modules) {
            if (m.isEnabled()) {
                try {
                    m.onGameMessage(message);
                } catch (RuntimeException e) {
                    crashed(m, e);
                }
            }
        }
    }

    private static void crashed(Module m, RuntimeException e) {
        HackClient.LOGGER.error("Module {} threw an exception and was disabled", m.getName(), e);
        m.setEnabled(false);
    }
}
