package dev.hackclient.module.impl;

import dev.hackclient.FriendManager;
import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

/** Disconnects from the server when health is low or a stranger comes close, then switches itself off. */
public final class AutoLeave extends Module {
    private final NumberSetting health = number("Health", 6, 0, 20, 1);
    private final NumberSetting playerRadius = number("PlayerRadius", 0, 0, 64, 1);
    private final BoolSetting ignoreFriends = bool("IgnoreFriends", true);

    public AutoLeave() {
        super("AutoLeave", Category.MOVEMENT, "Leaves the server on danger");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity self = mc.player;
        if (self == null || mc.world == null || mc.getNetworkHandler() == null) {
            return;
        }
        boolean lowHealth = health.get() > 0 && self.getHealth() <= health.get();
        boolean strangerNear = false;
        double radius = playerRadius.get();
        if (radius > 0) {
            for (PlayerEntity other : mc.world.getPlayers()) {
                if (other == self || (ignoreFriends.get() && FriendManager.isFriend(other.getEntityName()))
                        || AntiBot.isBot(other)) {
                    continue;
                }
                if (other.squaredDistanceTo(self) <= radius * radius) {
                    strangerNear = true;
                    break;
                }
            }
        }
        if (lowHealth || strangerNear) {
            setEnabled(false);
            mc.getNetworkHandler().getConnection().disconnect(Text.literal("[HackClient] AutoLeave"));
        }
    }
}
