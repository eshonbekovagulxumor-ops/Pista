package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Places a block from the hotbar under the player's feet whenever that spot is empty. Does not rotate the camera. */
public final class Scaffold extends Module {
    private final BoolSetting autoSwitch = bool("AutoSwitch", true);

    public Scaffold() {
        super("Scaffold", Category.MOVEMENT, "Auto-places blocks under your feet");
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.interactionManager == null
                || mc.currentScreen != null || player.getAbilities().flying) {
            return;
        }
        BlockPos below = player.getBlockPos().down();
        if (!mc.world.getBlockState(below).isAir()) {
            return;
        }
        int slot = findBlockSlot(player, autoSwitch.get());
        if (slot < 0) {
            return;
        }
        int previous = player.getInventory().selectedSlot;
        if (slot != previous) {
            if (!autoSwitch.get()) {
                return;
            }
            player.getInventory().selectedSlot = slot;
        }
        Vec3d hitPos = new Vec3d(below.getX() + 0.5, below.getY() + 1.0, below.getZ() + 0.5);
        BlockHitResult hit = new BlockHitResult(hitPos, Direction.UP, below, false);
        mc.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
        player.swingHand(Hand.MAIN_HAND);
        if (slot != previous) {
            player.getInventory().selectedSlot = previous;
        }
    }

    private static int findBlockSlot(ClientPlayerEntity player, boolean anySlot) {
        int current = player.getInventory().selectedSlot;
        ItemStack held = player.getInventory().main.get(current);
        if (held.getItem() instanceof BlockItem) {
            return current;
        }
        if (!anySlot) {
            return -1;
        }
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().main.get(i).getItem() instanceof BlockItem) {
                return i;
            }
        }
        return -1;
    }
}
