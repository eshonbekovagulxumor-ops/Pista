package dev.hackclient.module.impl;

import dev.hackclient.module.Category;
import dev.hackclient.module.Module;
import dev.hackclient.module.setting.BoolSetting;
import dev.hackclient.module.setting.ModeSetting;
import dev.hackclient.module.setting.NumberSetting;
import dev.hackclient.util.SilentRotation;
import dev.hackclient.util.Targets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Rotation is decided at the start of the tick (so the movement packet of that tick carries it), the attack happens at the end.
 * Rotation "Silent" leaves your camera alone, "Visible" turns the camera, "Off" never rotates.
 * Nothing here is tuned against a particular server's anti-cheat.
 */
public final class KillAura extends Module {
    private static LivingEntity currentTarget;
    private static boolean suppressSprint;

    private final NumberSetting range = number("Range", 3.0, 2.0, 6.0, 0.1);
    private final ModeSetting rotation = mode("Rotation", "Silent", "Silent", "Visible", "Off");
    private final BoolSetting onlyCrits = bool("OnlyCrits", false);
    private final BoolSetting critJump = bool("CritJump", false);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting hostiles = bool("Hostiles", true);
    private final BoolSetting passives = bool("Passives", false);
    private final BoolSetting advanced = bool("Advanced", false);
    private final NumberSetting fov = number("FOV", 180, 30, 360, 5);
    private final ModeSetting sort = mode("Sort", "Distance", "Distance", "Health", "Angle");
    private final BoolSetting invisible = bool("Invisible", false);
    private final BoolSetting wallCheck = bool("WallCheck", true);
    private final BoolSetting rayCheck = bool("RayCheck", true);
    private final BoolSetting onlyWeapon = bool("OnlyWeapon", true);
    private final BoolSetting noUseItem = bool("NoUseItem", true);
    private final NumberSetting turnSpeed = number("TurnSpeed", 30, 5, 180, 1);
    private final BoolSetting mouseGcd = bool("MouseGCD", true);
    private final NumberSetting minCooldown = number("MinCooldown", 0.92, 0.5, 1.0, 0.01);

    private LivingEntity target;
    private float requiredCooldown = 1.0f;
    private float silentYaw;
    private float silentPitch;
    private boolean hasSilent;
    private boolean jumpHeld;
    private float stepYaw;
    private float stepPitch;

    public KillAura() {
        super("KillAura", Category.COMBAT, "Attacks nearby entities");
        critJump.setVisibility(onlyCrits::get);
        for (var s : new dev.hackclient.module.setting.Setting[]{fov, sort, invisible, wallCheck, rayCheck,
                onlyWeapon, noUseItem, turnSpeed, mouseGcd, minCooldown}) {
            s.setVisibility(advanced::get);
        }
    }

    public static LivingEntity target() {
        return currentTarget;
    }

    public static boolean suppressSprint() {
        return suppressSprint;
    }

    @Override
    protected void onDisable() {
        reset();
    }

    private void reset() {
        target = null;
        currentTarget = null;
        suppressSprint = false;
        hasSilent = false;
        SilentRotation.clear();
        if (jumpHeld) {
            MinecraftClient.getInstance().options.jumpKey.setPressed(false);
            jumpHeld = false;
        }
    }

    private boolean canRun(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        return player != null && mc.world != null && mc.interactionManager != null
                && mc.currentScreen == null && player.isAlive()
                && (!onlyWeapon.get() || Targets.isHoldingWeapon(player));
    }

    @Override
    public void onPreTick(MinecraftClient mc) {
        if (!canRun(mc)) {
            reset();
            return;
        }
        ClientPlayerEntity player = mc.player;
        Vec3d eye = player.getEyePos();
        if (target == null || !isValid(player, target, eye)) {
            target = findTarget(player, mc.world, eye);
        }
        currentTarget = target;
        if (target == null || rotation.is("Off")) {
            releaseRotation(mc, player);
            return;
        }

        Vec3d aim = Targets.aimPoint(eye, target.getBoundingBox());
        float targetYaw = Targets.yawTo(eye, aim);
        float targetPitch = Targets.pitchTo(eye, aim);
        if (rotation.is("Silent")) {
            if (!hasSilent) {
                silentYaw = player.getYaw();
                silentPitch = player.getPitch();
                hasSilent = true;
            }
            stepToward(mc, silentYaw, silentPitch, targetYaw, targetPitch);
            silentYaw += stepYaw;
            silentPitch = MathHelper.clamp(silentPitch + stepPitch, -90.0f, 90.0f);
            SilentRotation.set(silentYaw, silentPitch);
        } else {
            hasSilent = false;
            SilentRotation.clear();
            stepToward(mc, player.getYaw(), player.getPitch(), targetYaw, targetPitch);
            if (stepYaw != 0.0f || stepPitch != 0.0f) {
                float oldPitch = player.getPitch();
                float newPitch = MathHelper.clamp(oldPitch + stepPitch, -90.0f, 90.0f);
                player.setYaw(player.getYaw() + stepYaw);
                player.setPitch(newPitch);
                player.prevYaw += stepYaw;
                player.prevPitch += newPitch - oldPitch;
            }
        }
    }

    /** After the target is gone, eases the silent rotation back to the camera so the server never sees a snap. */
    private void releaseRotation(MinecraftClient mc, ClientPlayerEntity player) {
        if (!hasSilent) {
            SilentRotation.clear();
            return;
        }
        stepToward(mc, silentYaw, silentPitch, player.getYaw(), player.getPitch());
        silentYaw += stepYaw;
        silentPitch = MathHelper.clamp(silentPitch + stepPitch, -90.0f, 90.0f);
        float err = (float) Math.hypot(MathHelper.wrapDegrees(player.getYaw() - silentYaw), player.getPitch() - silentPitch);
        if (err < 1.0f) {
            hasSilent = false;
            SilentRotation.clear();
        } else {
            SilentRotation.set(silentYaw, silentPitch);
        }
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (jumpHeld) {
            mc.options.jumpKey.setPressed(false);
            jumpHeld = false;
        }
        suppressSprint = false;
        if (player == null || target == null || !canRun(mc)) {
            return;
        }
        suppressSprint = onlyCrits.get();
        if (noUseItem.get() && player.isUsingItem()) {
            return;
        }
        if (player.getAttackCooldownProgress(0.5f) < requiredCooldown) {
            return;
        }
        if (onlyCrits.get() && !Targets.canCrit(player)) {
            if (player.isSprinting() && !player.isOnGround()) {
                player.setSprinting(false);
            } else if (critJump.get() && player.isOnGround() && !player.isTouchingWater()) {
                mc.options.jumpKey.setPressed(true);
                jumpHeld = true;
            }
            return;
        }
        Vec3d eye = player.getEyePos();
        if (rayCheck.get() && !lookingAt(player, eye, target.getBoundingBox())) {
            return;
        }
        mc.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        float min = minCooldown.getFloat();
        requiredCooldown = min + ThreadLocalRandom.current().nextFloat() * (1.0f - min);
    }

    private boolean isValid(ClientPlayerEntity player, Entity e, Vec3d eye) {
        if (!Targets.isAttackable(e, players.get(), hostiles.get(), passives.get(), invisible.get())) {
            return false;
        }
        Box box = e.getBoundingBox();
        if (Targets.distanceToBox(eye, box) > range.get()) {
            return false;
        }
        if (fov.get() < 360.0) {
            float yawDiff = Math.abs(MathHelper.wrapDegrees(Targets.yawTo(eye, Targets.aimPoint(eye, box)) - player.getYaw()));
            if (yawDiff > fov.get() / 2.0) {
                return false;
            }
        }
        return !wallCheck.get() || player.canSee(e);
    }

    private LivingEntity findTarget(ClientPlayerEntity player, ClientWorld world, Vec3d eye) {
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity e : world.getEntities()) {
            if (!(e instanceof LivingEntity living) || !isValid(player, e, eye)) {
                continue;
            }
            double score;
            if (sort.is("Health")) {
                score = living.getHealth();
            } else if (sort.is("Angle")) {
                score = Math.abs(MathHelper.wrapDegrees(Targets.yawTo(eye, Targets.aimPoint(eye, e.getBoundingBox())) - player.getYaw()));
            } else {
                score = Targets.distanceToBox(eye, e.getBoundingBox());
            }
            if (score < bestScore) {
                bestScore = score;
                best = living;
            }
        }
        return best;
    }

    private boolean lookingAt(ClientPlayerEntity player, Vec3d eye, Box box) {
        if (box.contains(eye)) {
            return true;
        }
        Vec3d look = SilentRotation.isActive()
                ? Vec3d.fromPolar(SilentRotation.pitch(), SilentRotation.yaw())
                : player.getRotationVec(1.0f);
        return box.raycast(eye, eye.add(look.multiply(range.get() + 0.5))).isPresent();
    }

    /** Computes the next rotation step (stepYaw/stepPitch) from the current angles toward the target angles. */
    private void stepToward(MinecraftClient mc, float curYaw, float curPitch, float targetYaw, float targetPitch) {
        stepYaw = 0.0f;
        stepPitch = 0.0f;
        float yawErr = MathHelper.wrapDegrees(targetYaw - curYaw);
        float pitchErr = targetPitch - curPitch;
        float err = (float) Math.hypot(yawErr, pitchErr);
        if (err < 0.01f) {
            return;
        }
        float maxStep = turnSpeed.getFloat() * (0.8f + ThreadLocalRandom.current().nextFloat() * 0.4f);
        float scale = err > maxStep ? maxStep / err : 1.0f;
        float dYaw = yawErr * scale;
        float dPitch = pitchErr * scale;
        if (mouseGcd.get()) {
            float step = mouseStep(mc);
            dYaw = Math.round(dYaw / step) * step;
            dPitch = Math.round(dPitch / step) * step;
        }
        stepYaw = dYaw;
        stepPitch = dPitch;
    }

    /** Smallest rotation a real mouse can produce at the current sensitivity (vanilla: (s*0.6+0.2)^3 * 8 * 0.15). */
    private static float mouseStep(MinecraftClient mc) {
        double f = mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        return (float) (f * f * f * 8.0 * 0.15);
    }
}
